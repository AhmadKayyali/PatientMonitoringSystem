package edu.rmit.vitalsignsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VitalsignsserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
